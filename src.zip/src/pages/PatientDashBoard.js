import React from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/patient.jpg';

function PatientDashboard() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('currentUser'));

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-3">
          { <img src={logo} alt="DentiCare" className="h-20 w-20" /> }
          <h1 className="text-3xl font-bold text-teal-700">DentiCare</h1>
        </div>
        <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
          Logout
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-2xl font-semibold text-gray-800 mb-2">
          Welcome, <span className="text-teal-700">{user?.email}</span>
        </h2>
        <p className="text-gray-600 mb-6">Here's a quick overview of your dental history.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="text-xl font-bold text-teal-600 mb-2">Upcoming Appointments</h3>
            <ul className="list-disc list-inside text-gray-700 space-y-1">
              <li>Scaling - Jul 5, 10:00 AM</li>
              <li>Filling - Aug 12, 3:00 PM</li>
            </ul>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="text-xl font-bold text-teal-600 mb-2">Past Treatments</h3>
            <ul className="list-disc list-inside text-gray-700 space-y-1">
              <li>Tooth Extraction - ₹1500 - Completed</li>
              <li>Root Canal - ₹5000 - Completed</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PatientDashboard;
