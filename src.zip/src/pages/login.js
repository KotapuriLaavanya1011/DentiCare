import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/DentiCare.jpg'; 

const users = [
  { email: 'admin@entnt.in', password: 'admin123', role: 'admin' },
  { email: 'patient@entnt.in', password: 'patient123', role: 'patient' }
];

function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('patient');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const user = users.find(u => u.email === email && u.password === password);
    if (isLogin) {
      if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        navigate(user.role === 'admin' ? '/admin' : '/patient');
      } else {
        setError('Invalid email or password');
      }
    } else {
      users.push({ email, password, role });
      localStorage.setItem('currentUser', JSON.stringify({ email, role }));
      navigate(role === 'admin' ? '/admin' : '/patient');
    }
  };

  return (
<div className="min-h-screen flex flex-col md:flex-row items-center justify-center bg-gray-100">
      <div className="w-full md:w-1/2 p-10 flex flex-col items-center">
<img
  src={logo}
  alt="DentiCare Logo"
  className="w-45 h-45 mb-3 transform transition-transform duration-500 hover:scale-110"
/>
        <h1 className="text-4xl font-extrabold text-teal-800 mb-2">DentiCare</h1>
        <p className="text-gray-600 text-center">Manage your dental appointments with ease and precision.</p>
      </div>

      <div className="w-full md:w-1/3 bg-white p-8 rounded-xl shadow-xl">
        <h2 className="text-2xl font-bold mb-4">{isLogin ? 'Login' : 'Register'}</h2>
        {error && <p className="text-red-500">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            className="w-full border border-gray-300 p-2 rounded"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            className="w-full border border-gray-300 p-2 rounded"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {!isLogin && (
            <select
              className="w-full border border-gray-300 p-2 rounded"
              value={role}
              onChange={(e) => setRole(e.target.value)}
            >
              <option value="patient">Patient</option>
              <option value="admin">Admin</option>
            </select>
          )}
          <button
            type="submit"
            className="w-full bg-teal-600 text-white py-2 rounded hover:bg-teal-700 transition"
          >
            {isLogin ? 'Login' : 'Register'}
          </button>
        </form>
        <p className="mt-4 text-sm text-gray-500 text-center">
          {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-teal-700 font-medium hover:underline"
          >
            {isLogin ? 'Register here' : 'Login'}
          </button>
        </p>
      </div>
    </div>
  );
}

export default Login;
