import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import DashboardImg from '../assets/careDt.png';

function AdminDashboard() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-100 via-white to-teal-50 p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-extrabold text-teal-800">Hello-Dentist</h1>
        <button onClick={handleLogout} className="bg-red-500 text-white px-5 py-2 rounded-full shadow hover:bg-red-600 transition">
          Logout
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <motion.div 
          className="bg-white p-6 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-xl font-semibold text-teal-700 mb-2">Next Appointments</h2>
          <p className="text-gray-600">10 upcoming treatments</p>
        </motion.div>

        <motion.div 
          className="bg-white p-6 rounded-xl shadow-lg"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-xl font-semibold text-teal-700 mb-2">Top Patients</h2>
          <p className="text-gray-600">Based on visit frequency</p>
        </motion.div>

        <motion.div 
          className="bg-white p-6 rounded-xl shadow-lg md:col-span-2 flex flex-col md:flex-row items-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          { <img src={DashboardImg} alt="Dental Illustration" className="w-64 h-auto mb-4 md:mb-0 md:mr-8" /> }
          <div>
            <h2 className="text-2xl font-bold text-teal-800 mb-2">Welcome back, Doctor!</h2>
            <p className="text-gray-700">
              Let’s take care of your patients. You can manage patients, appointments, and treatments with ease.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default AdminDashboard;
